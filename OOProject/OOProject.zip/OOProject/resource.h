﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by OOProject.rc
//
#define IDD_OOPROJECT_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP_SMALL_DOG            137
#define IDB_BITMAP_SMALL_COW            139
#define IDB_BITMAP_SMALL_SNAKE          140
#define IDB_BITMAP_PLUS                 141
#define IDB_BITMAP_MINUS                142
#define IDB_BITMAP_REDO                 143
#define IDB_BITMAP_UNDO                 144
#define IDB_BITMAP_LOAD                 145
#define IDB_BITMAP_SAVE                 146
#define IDC_EDIT1                       1000
#define IDC_TEXTBOX                     1000
#define ID_MINUS_DOG                    1007
#define ID_PLUS_DOG                     1008
#define IDC_BUTTON15                    1010
#define IDC_BUTTON_UNDO                 1010
#define ID_DOG                          1011
#define IDC_BUTTON9                     1013
#define IDC_MINUS_COW                   1013
#define IDC_BUTTON10                    1014
#define IDC_PLUS_COW                    1014
#define IDC_DOG                         1015
#define IDC_BUTTON12                    1016
#define IDC_MINUS_SNAKE                 1016
#define IDC_BUTTON13                    1017
#define IDC_PLUS_SNAKE                  1017
#define IDC_COW                         1018
#define IDC_SNAKE                       1019
#define IDC_FARM                        1020
#define IDC_BUTTON16                    1021
#define IDC_BUTTON_REDO                 1021
#define IDC_BUTTON17                    1022
#define IDC_BUTTON_LOAD                 1022
#define IDC_BUTTON18                    1023
#define IDC_BUTTON_SAVE                 1023
#define IDC_BUTTON1                     1024
#define IDC_BUTTONHELP                  1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        147
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
